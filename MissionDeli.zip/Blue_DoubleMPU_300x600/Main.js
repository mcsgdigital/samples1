var isExitDC = false;

window.onload = function init() {
    if (Enabler.isInitialized()) {
        enablerInitHandler();
    } else {
        Enabler.addEventListener(studio.events.StudioEvent.INIT, enablerInitHandler);
    }
}

function enablerInitHandler(){
  if (Enabler.isPageLoaded()) {
    pageLoadedHandler();
  } else {
    Enabler.addEventListener(studio.events.StudioEvent.PAGE_LOADED,
    pageLoadedHandler);
  }
}


function pageLoadedHandler() {
    banner();
}

function banner(){
    // EXITS and TRACKING
    getElement("id", "bg-exit").onclick=function(){
        if(isExitDC){
            Enabler.exit('Backup Exit');
        } else{
            window.open(window.clickTag);
        }
        Enabler.counter('Tracking click.');
    };
    
    var background = getElement("id", "background");
    var background2 = getElement("id", "background2");
    
    var wraps = [
        getElement("id", "wrap1"),
        getElement("id", "wrap2"),
        getElement("id", "wrap3"),
        getElement("id", "wrap4")
    ];
    
    var copies = [
        getElement("id", "copy1"),
        getElement("id", "copy2"),
        getElement("id", "copy3")
    ];
    
    var product = getElement("id", "product");
    var logoSmall = getElement('id', "logoSmall");
    var cta = getElement('id', "cta");
    
    startAnim();

    function startAnim(){
        var del = 0;
        
        setTimeout(function(){
            wraps[0].setAttribute("style","opacity:0; -moz-opacity:0; filter:alpha(opacity=0)");
            wraps[1].setAttribute("style","opacity:1; -moz-opacity:1; filter:alpha(opacity=1)");
        },del += 750);

        setTimeout(function(){
            wraps[1].setAttribute("style","opacity:0; -moz-opacity:0; filter:alpha(opacity=0)");
            wraps[2].setAttribute("style","opacity:1; -moz-opacity:1; filter:alpha(opacity=1)");
        },del += 750);
        
        setTimeout(function(){
            wraps[2].setAttribute("style","opacity:0; -moz-opacity:0; filter:alpha(opacity=0)");
            wraps[3].setAttribute("style","opacity:1; -moz-opacity:1; filter:alpha(opacity=1)");
        },del += 750);
        
        setTimeout(function(){
            wraps[3].setAttribute("style","opacity:0; -moz-opacity:0; filter:alpha(opacity=0)");
            background2.setAttribute("style","opacity:1; -moz-opacity:1; filter:alpha(opacity=1)");
            
        },del += 1500);
        
        setTimeout(function(){
            copies[0].setAttribute("style","opacity:1; -moz-opacity:1; filter:alpha(opacity=1)");
        },del += 500);
        
        setTimeout(function(){
            copies[0].setAttribute("style","opacity:0; -moz-opacity:0; filter:alpha(opacity=0)");
        },del += 2000);
        
        setTimeout(function(){
            copies[1].setAttribute("style","opacity:1; -moz-opacity:1; filter:alpha(opacity=1)");
        },del += 500);
        
        setTimeout(function(){
            copies[1].setAttribute("style","opacity:0; -moz-opacity:0; filter:alpha(opacity=0)");
        },del += 1500);
        
        setTimeout(function(){
            product.setAttribute("style","opacity:1; -moz-opacity:1; filter:alpha(opacity=1)");
            cta.setAttribute("style","opacity:1; -moz-opacity:1; filter:alpha(opacity=1)");
        },del += 500);
    }
}

function getElement(element, id) {
  var obj;
  switch(element){
    case "id":
      obj = document.getElementById(id);
    break;
    case "class":
      obj = document.getElementsByClassName(id);
    break;
  }

  return obj;
}


