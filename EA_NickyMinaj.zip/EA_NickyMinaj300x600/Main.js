var stage;
var container;
var queue;
var copy1,copy2,copy3,copy4;
var cta,logo;
var img;
var mask,sparkle;
var ref,gif;
var sp;
var panel;

function init() {
    stage = new createjs.Stage("canvas");
	container = new createjs.Container();
	stage.addChild(container);
	
	stage.enableMouseOver();
	
	preloadImages();
}

function preloadImages() {
	
	queue = new createjs.LoadQueue(false);
	queue.on("complete", handleFileComplete);
	queue.loadFile({id: "sp", src:"spritesheet.jpg"});
	queue.loadFile({id: "girl", src:"girl.jpg"});
	queue.loadFile({id: "bottle", src:"bottle.jpg"});
	queue.loadFile({id: "sparkle", src:"sparkle.png"});
	queue.loadFile({id: "ref", src:"ref.jpg"});
	queue.loadFile({id: "panel", src:"lastFramePanel.jpg"});
}

function handleFileComplete(event) {
	setup();
}

function setup(){
	
	var girlImage = queue.getResult("girl");
	girl = new createjs.Bitmap(girlImage);
	container.addChild(girl);
	//girl.scaleX = girl.scaleY = .84;
	girl.x = -70;
	girl.y = 0;
	var bottleImage = queue.getResult("bottle");
	bottle = new createjs.Bitmap(bottleImage);
	container.addChild(bottle);
	bottle.x = 0;
	bottle.y = 0;
	
	var sparkleImage = queue.getResult("sparkle");
	sparkle = new createjs.Bitmap(sparkleImage);
	container.addChild(sparkle);
	sparkle.regX = 50;
	sparkle.regY = 50
	sparkle.x = 128;
	sparkle.y = 220;
	sparkle.alpha = 0;
	sparkle.scaleX = sparkle.scaleY = .5;
	
	var refImage = queue.getResult("ref");
	ref = new createjs.Bitmap(refImage);
	container.addChild(ref);
	ref.x = 0;
	ref.y = 0;
	ref.alpha = 0;
	
	
	
	var spriteSheet = new createjs.SpriteSheet({
			framerate: 30,
			images: [queue.getResult("sp")],
			frames: {width:300, height:96, regX:0, regY:45, count:48, spacing:0, margin:0},
			// define two animations, run (loops, 1.5x speed) and jump (returns to run):
			animations: {
				run: [0, 47,"end"],
				end: 47
			}
		});
		
	sp = new createjs.Sprite(spriteSheet, "run");
	sp.x = 0;
	sp.y = 700;	
	stage.addChild(sp);
	
	
	blackMask = new createjs.Shape();
	blackMask.graphics.beginFill("black").drawRect(0,0,800,1200);
	blackMask.rotation = 45;
	blackMask.x = 300;
	blackMask.y = -300;
	stage.addChild(blackMask);
	
	mask = new createjs.Shape();
		mask.x = 0;
		mask.y = -300;
		mask.graphics.beginStroke("black").setStrokeStyle(1).drawRect(0,0,800,800).closePath();
		stage.addChild(mask);
		mask.rotation = 135;
		
	bottle.mask = mask;
	
	createjs.Tween.get(blackMask).wait(500).to({x:-600,y:600},700).wait(1500).call(function(){
		fadeGirl();
	});
	
	createjs.Ticker.setFPS(20);
	createjs.Ticker.addEventListener("tick", handleTick);
	
	//BORDER
	var background = new createjs.Shape();
	background.graphics.s("#d81ab4").drawRect(0, 0, 300, 600);
	stage.addChild(background)
}

function handleTick(event) {
	if (!event.paused) {
		stage.update();
	}
}

function fadeGirl(){
	createjs.Tween.get(mask).to({x:600,y:300},1500);
	createjs.Tween.get(sparkle).wait(500).to({alpha: 1},500);
	setTimeout(animateSparkle, 500);
}

function animateSparkle(){
	createjs.Tween.get(girl).wait(500).to({alpha: 0},500);
	createjs.Tween.get(sparkle, { loop: true })
  .to({rotation: 180,scaleX:.75,scaleY:.75},1000)
  .to({rotation: 360,scaleX:.5,scaleY:.5},1000);
  
  setTimeout(showRef, 3000);
}

function showRef(){
	createjs.Tween.get(bottle).to({alpha: 0},500);
	createjs.Tween.get(sparkle).to({alpha: 0},500);
	createjs.Tween.get(ref).to({alpha: 1},500);
	
	createjs.Tween.get(ref).wait(3000).to({y:-600},500);
	createjs.Tween.get(sp).wait(3000).to({y:300},500);
	setTimeout(showSignature, 3000);
}

function showSignature(){
	sp.gotoAndPlay("run");
	
	setTimeout(showLastFrame, 3000);
}

function showLastFrame(){
	/*var blackCover = new createjs.Shape();
	blackCover.graphics.beginFill("black").drawRect(0,0,50,600);
	blackCover.x = 165;
	blackCover.y = 0;
	container.addChild(blackCover);*/
	
	var panelImage = queue.getResult("panel");
	panel = new createjs.Bitmap(panelImage);
	container.addChild(panel);
	panel.x = 0;
	panel.y = 600;
	
	girl.scaleX = girl.scaleY = .75;
	girl.x = -10;
	girl.y = -600;
	girl.alpha = 1;
	createjs.Tween.get(girl).wait(500).to({y:0},150);
	createjs.Tween.get(panel).wait(500).to({y:300},250);
	
	createjs.Tween.get(sp).to({alpha:0},300);
}





