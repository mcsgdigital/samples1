/* Developed by
Mark CHANTEL
mark147chantel@gmail.com */

var loop = 1;
var background,copy1,copy2,cta,logo,doodle;
var F,a,t,h,e,r,s,d,a2,y;
var s1,s2,s3,loopSparkle;

window.onload = function init() {
    banner();
}

function banner(){
    // EXITS and TRACKING
    getElement("id", "bg-exit").onclick=function(){
        window.open(window.clickTag);
    };
    
    background = getElement("id", "background");
    copy1 = getElement("id", "copy1");
    copy2 = getElement("id", "copy2");
    cta = getElement('id', "cta");
    logo = getElement('id', "logo");
    doodle = getElement('id', "doodle");
	
	F = getElement("id", "FD_F");
	a = getElement("id", "FD_a");
	t = getElement("id", "FD_t");
	h = getElement("id", "FD_h");
	e = getElement("id", "FD_e");
	r = getElement("id", "FD_r");
	s = getElement("id", "FD_s");
	d = getElement("id", "FD_d");
	a2 = getElement("id", "FD_a2");
	y = getElement("id", "FD_y");
	
    s1 = getElement('id', "sparkle1");
    s2 = getElement('id', "sparkle2");
    s3 = getElement('id', "sparkle3");
    
    loopSparkle = 0;
    
    startAnim();
}

function startAnim(){
	var del = 0;
	TweenLite.to(logo, 0, {css: {scaleX: .1, scaleY: .1}});
	
	TweenLite.to(copy1, 0, {opacity:"0px", onComplete: animateLetters});
	TweenLite.to(copy2, 1, {left:"0px", ease: Bounce.easeOut, delay: .5});
	TweenLite.to(logo, 0, {opacity:"1", delay: 3});
	TweenLite.to(logo, .5, {css: {scaleX: 1, scaleY: 1, transformOrigin: "center center"}, delay: 3, ease: Bounce.easeOut, overwrite: false});
	TweenLite.to(background, 1.6, {left:"0px", ease: Power0.easeOut, delay: 1});
	TweenLite.to(doodle, .2, {opacity:"1", delay: 5});
	TweenLite.to(copy3, .2, {opacity:"1", delay: 3.5, onComplete: animateSparkle});
	TweenLite.to(cta, 0, {opacity:"1", delay: 4.5});
	
	setTimeout(loopBanner, 7000);
}

function getElement(element, id) {
  var obj;
  switch(element){
    case "id":
      obj = document.getElementById(id);
    break;
    case "class":
      obj = document.getElementsByClassName(id);
    break;
  }

  return obj;
}

function animateLetters(){
	TweenLite.to(F, .4, {top:"100px", ease: Back.easeOut});
	TweenLite.to(a, .4, {top:"100px", ease: Back.easeOut, delay: .1});
	TweenLite.to(t, .4, {top:"100px", ease: Back.easeOut, delay: .18});
	TweenLite.to(h, .4, {top:"100px", ease: Back.easeOut, delay: .26});
	TweenLite.to(e, .4, {top:"100px", ease: Back.easeOut, delay: .34});
	TweenLite.to(r, .4, {top:"100px", ease: Back.easeOut, delay: .42});
	TweenLite.to(s, .4, {top:"100px", ease: Back.easeOut, delay: .5});
	TweenLite.to(d, .4, {top:"100px", ease: Back.easeOut, delay: .58});
	TweenLite.to(a2, .4, {top:"100px", ease: Back.easeOut, delay: .66});
	TweenLite.to(y, .4, {top:"100px", ease: Back.easeOut, delay: .74});
}

function animateSparkle(){
    if(loopSparkle < 2){
        loopSparkle++;
        TweenLite.to(s1, 0, {opacity:"1", ease: Back.easeOut});
        TweenLite.to(s1, 0, {opacity:"0", ease: Back.easeOut, delay: .3, overwrite: false});
        TweenLite.to(s2, 0, {opacity:"1", ease: Back.easeOut, delay: .3});
        TweenLite.to(s2, 0, {opacity:"0", ease: Back.easeOut, delay: .6, overwrite: false});
        TweenLite.to(s3, 0, {opacity:"1", ease: Back.easeOut, delay: .6});
        TweenLite.to(s3, 0, {opacity:"0", ease: Back.easeOut, delay: 1, overwrite: false}); 
        
        setTimeout(animateSparkle, 1500);
    }
}

function loopBanner(){
	if(loop < 2){
		loop++;
        loopSparkle = 0;
		TweenLite.to(background, 0, {left:"-320px"});
		TweenLite.to(copy2, 0, {left:"-300px"});
		TweenLite.to(logo, 0, {opacity:"0"});
		TweenLite.to(cta, 0, {opacity:"0"});
		TweenLite.to(doodle, 0, {opacity:"0"});
		TweenLite.to(copy3, 0, {opacity:"0"});
		
		doodle.src = 'assets/rosette_anim.gif';
		
		TweenLite.to(F, 0, {top:"-100px"});
		TweenLite.to(a, 0, {top:"-100px"});
		TweenLite.to(t, 0, {top:"-100px"});
		TweenLite.to(h, 0, {top:"-100px"});
		TweenLite.to(e, 0, {top:"-100px"});
		TweenLite.to(r, 0, {top:"-100px"});
		TweenLite.to(s, 0, {top:"-100px"});
		TweenLite.to(d, 0, {top:"-100px"});
		TweenLite.to(a2, 0, {top:"-100px"});
		TweenLite.to(y, 0, {top:"-100px"});
		
		startAnim();
	}
}

